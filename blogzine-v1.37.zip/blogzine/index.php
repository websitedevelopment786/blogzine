<?php get_header(); ?>

<style type="text/css">
article.type-post {max-width: 750px;margin: 2rem auto;display: flex;flex-direction: column;gap: 1rem;}
article.type-post img {box-shadow: 0 0 6px 1px #0000004a;}
.archive-pg {padding: 1rem 0 1.8rem;text-align: center;margin: auto;border-bottom: 1px solid #F2F2F2;margin-bottom: 2rem;}
.archive-pg .page-header {display: flex;flex-direction: column;max-width: 800px;margin: auto;gap: 10px;}
.page-header .post-count span {display: inline-block;color: white;background-color: #191919;padding: 8px 16px;border-radius: 99em;margin-top: 2px;}
.pagination .nav-links {display: flex;gap: 8px;justify-content: center;align-items: center;flex-wrap: wrap;max-width: 800px;}
.pagination .nav-links .page-numbers {border: 1px solid black;color: black;background-color: white;padding: 6px 14px;border-radius: 99em;}
.pagination .nav-links .page-numbers.current {color: white;background-color: #191919;}
.post-grid {display: flex;gap: 2rem;flex-wrap: wrap;justify-content: center;}
.post-grid article {width: 31.5%;display: flex;flex-direction: column;gap: 10px;margin: 0;}
.post-grid article .post-thumbnail {height: 260px;display: flex;align-items: stretch;justify-content: center;box-shadow: 0 0 6px 1px #00000054;margin-bottom: 8px;}
.post-grid article .post-thumbnail a {display: flex;align-items: stretch;justify-content: center;width: 100%;overflow: hidden;}
.post-grid article .post-thumbnail img {width: 100%;object-fit: cover;transition: all 0.3s ease-in-out;}
.post-grid article .post-thumbnail:hover img {scale: 1.1;}
.post-grid article .post-title {font-size: 20px;line-height: 24px;color: #242424;margin: 0;}
.post-grid article .post-content p {margin: 0;display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;overflow: hidden;text-overflow: ellipsis;word-break: break-word;line-height: 1.5;max-height: calc(1.5em* 2);}
.post-grid article.no-thumb .post-content p {-webkit-line-clamp: 8;max-height: calc(1.5em* 8);}
.post-grid article.no-thumb {justify-content: center !important;display: flex !important;box-shadow: 0 0 6px 1px #00000054;padding: 2rem;gap: 25px;}
article.type-post .post-grid.related-posts {gap: 2rem;}
article.type-post .post-grid.related-posts article {width: 47%;}
.comment-form input {border-radius: 0;padding: 5px 8px;border: 1px solid #191919;}
.comment-form textarea {border-radius: 0;height: 100px;border: 1px solid #191919;}
.comment-form label {margin-bottom: 8px;font-weight: 600;}
.comment-form input[type=checkbox] {border-radius: 0;width: 20px;border: 1px solid;}
article .required {color: red;}
.comment-form input#submit {color: #191919;background-color: white;padding: 8px 16px;border-radius: 99em;border: 2px solid #191919;font-weight: 600;}
.commentlist {padding: 1rem 0;display: flex;flex-direction: column;gap: 20px;}
.commentlist .comment {display: flex;flex-direction: column;gap: 15px;}
.commentlist .comment article {box-shadow: 0 0 6px 1px #00000030;padding: 15px;}
.comment article .comment-author {display: flex;align-items: center;margin-bottom: 12px;gap: 10px;}
.comment article .comment-author .avatar {border-radius: 50%;}
.comment .reply .comment-reply-link {color: green;}
.comment .comment-metadata {margin-bottom: 3px;}
.comment .comment-awaiting-moderation {color: crimson;}
.archive-pg .page-header .author-avatar {margin: 1rem 0 0px;}
.archive-pg .page-header .author-avatar img {border-radius: 50%;box-shadow: 0 0 6px 1px #00000061;width: 100px;}
article.type-post .list-post-meta {display: flex;flex-direction: column;gap: 10px;margin-top: 4px;}
article.type-post .list-post-meta .post-meta-left {display: flex;gap: 10px;}
article.type-post .list-post-meta .post-meta-left .left-meta-content {display: flex;flex-direction: column;gap: 4px;font-size: 13px;line-height: 12px;text-transform: capitalize;}
article.type-post .list-post-meta .author-avatar img {width: 28px;border-radius: 50%;box-shadow: 0 0 6px 1px #0000005e;}
article.type-post .list-post-meta .post-meta-right .post-categories {padding: 0;display: flex;flex-direction: row;flex-wrap: wrap;gap: 8px;}
article.type-post .list-post-meta .post-meta-right .post-categories li, article.type-post .post-tags a {list-style: none;background-color: #F2F2F2;padding: 3px 10px;font-size: 12px;border-radius: 99rem;}
article.type-post .post-title:hover, article.type-post a:hover {text-decoration: underline;}
article.type-post .list-post-meta.single-post {margin-bottom: 1rem;}
article.type-post .post-tags {display: flex;flex-wrap: wrap;gap: 10px;align-items: center;margin-bottom: 10px;}
article.type-post .post-navigation {display: flex;margin: 5px 0;}
article.type-post .post-navigation .nav-previous {width: 50%;display: flex;border-right: 1px solid #F2F2F2;padding-right: 10px;}
article.type-post .post-navigation .nav-previous a {display: flex;gap: 16px;align-items: center;}
article.type-post .post-navigation .nav-post-thumb {width: 25%;display: flex;}
article.type-post .post-navigation .nav-post-content {display: flex;flex-direction: column;width: 100%;}
article.type-post .post-navigation .nav-next {width: 50%;display: flex;padding-left: 10px;justify-content: end;}
article.type-post .post-navigation .nav-next a {display: flex;align-items: center;justify-content: end;text-align: end;gap: 16px;}
article.type-post .wp-block-gallery, article.type-post .wp-block-embed, article.type-post .view-full {width: 100vw !important;max-width: 1200px !important;padding: 2rem 0;position: relative;left: 50%;transform: translateX(-50%);}
article.type-post .alignfull {position: relative;left: 50%;transform: translateX(-50%);margin-left: auto;margin-right: auto;}
article.type-post .post-thumbnail.view-full {padding: 0 0 1rem !important;}
article.type-post .post-navigation .nav-post-title {display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;overflow: hidden;text-overflow: ellipsis;word-break: break-word;max-height: calc(1.5em* 2);}
@media screen and (max-width: 1350px) {
    .post-grid {gap: 1rem;}
    .post-grid article {width: 32%;}
    .post-grid article .post-thumbnail {height: 220px;}
}
@media screen and (max-width: 1250px) {
    article.type-post .wp-block-gallery, article.type-post .wp-block-embed, article.type-post .view-full {width: 100% !important;max-width: 100% !important;margin-left: 0;padding: 1rem 0;}
}
@media screen and (max-width: 900px) {
    .post-grid article {width: 48%;}
    .post-grid article .post-thumbnail {height: 200px;}
}
@media screen and (max-width: 650px) {
    article.type-post .post-grid.related-posts article {width: 85%;}
    .page-header .page-title {font-size: 28px;line-height: 38px;}
    .pagination .nav-links .page-numbers {padding: 4px 12px;}
}
@media screen and (max-width: 550px) {
    .post-grid {gap: 2rem;}
    .post-grid article {width: 100%;}
    article.type-post .post-grid.related-posts article {width: 100%;}
    article.type-post .post-title, article.type-post h1 {font-size: 28px;line-height: 33px;}
    article.type-post h2 {font-size: 28px;line-height: 32px;}
    article.type-post h3 {font-size: 25px;line-height: 28px;}
    article.type-post h4, article.type-post h5, article.type-post h6 {font-size: 18px;line-height: 22px;}
    article.type-post .post-navigation {flex-wrap: wrap;gap: 15px;}
    article.type-post .post-navigation .nav-previous, article.type-post .post-navigation .nav-next, article.type-post .post-navigation .nav-previous a, article.type-post .post-navigation .nav-next a {width: 100%;border: 0;}
}
</style>

<main class="container">
    <!-- title -->
    <?php if (is_archive() || is_home() || is_search()) : ?>
        <div class="archive-pg">
            <!-- cat slider -->
            <?php if (shortcode_exists('category_slider')) { echo do_shortcode('[category_slider]'); } ?>
            <!-- header -->
            <div class="page-header">
                <!-- avatar -->
                <?php if (is_author()) { ?>
                    <?php $author_id = get_queried_object_id(); ?>
                    <div class="author-avatar">
                        <?php echo get_avatar($author_id, 100); ?>
                    </div>
                <?php } ?>
                <!-- title -->
                <h1 class="page-title">
                    <?php
                        if (is_search()) { printf(__('Search Results for: %s', 'blogzine'), get_search_query()); }
                        elseif (is_archive()) { the_archive_title(); }
                        elseif (is_home()) { echo get_the_title(get_option('page_for_posts')); }
                        else { echo __('Latest Posts', 'blogzine'); }
                    ?>
                </h1>
                <!-- description -->
                <?php if (get_the_archive_description()) : ?>
                    <?php the_archive_description(); ?>
                <?php endif; ?>
                <!-- post count -->
                <p class="post-count">
                    <span>
                    <?php 
                        $total_posts = $wp_query->found_posts;
                        echo sprintf(__('%s Posts', 'blogzine'), millers_format_number($total_posts)); 
                    ?>
                    </span>
                </p>
            </div>
        </div>
    <?php endif; ?>
    <!-- main -->
    <?php
        if (have_posts()) {
            if (is_archive() || is_home() || is_search()) echo '<div class="post-grid">';
            while (have_posts()) {
                the_post();
                get_template_part('template-parts/content', get_post_type());
            }
            if (is_archive() || is_home() || is_search()) echo '</div>';
        } else { echo '<p>' . __('No content available.', 'blogzine') . '</p>'; }
    ?>
    <!-- pagination -->
    <?php if (is_archive() || is_home() || is_search()) : ?>
        <!-- post pagination -->
        <div class="pagination">
            <?php
                the_posts_pagination([
                    'mid_size'  => 2,
                    'prev_text' => __('&laquo; Previous', 'blogzine'),
                    'next_text' => __('Next &raquo;', 'blogzine'),
                ]);
            ?>
        </div>
    <?php endif; ?>
</main>

<?php get_footer(); ?>