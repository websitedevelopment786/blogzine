<?php
/**
 * The template for displaying comments
 *
 * @package BlogZine
 */


// If the post is password-protected, do not display comments.
if (post_password_required()) {
    return;
}
?>

<div id="comments" class="comments-area">
    <?php if (have_comments()) : ?>
        <h2 class="comments-title">
            <?php
            $comment_count = get_comments_number();
            if ($comment_count == 1) {
                echo esc_html__('One comment', 'blogzine');
            } else {
                echo esc_html($comment_count . ' ' . __('comments', 'blogzine'));
            }
            ?>
        </h2>

        <ul class="comment-list">
            <?php
            wp_list_comments(array(
                'style'       => 'ul',
                'short_ping'  => true,
                'avatar_size' => 50,
            ));
            ?>
        </ul>

        <?php the_comments_navigation(); ?>

    <?php endif; ?>

    <?php if (comments_open()) : ?>
        <?php comment_form(); ?>
    <?php endif; ?>
</div>
