<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Millers_Search_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'millers_search';
    }

    public function get_title() {
        return __('Millers Search', 'blogzine');
    }

    public function get_icon() {
        return 'eicon-search';
    }

    public function get_categories() {
        return ['millers-widgets'];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_search_input',
            [
                'label' => __('Search Input', 'blogzine'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'input_typography',
                'label' => __('Typography', 'blogzine'),
                'selector' => '{{WRAPPER}} .millers-search-input',
            ]
        );

        $this->add_control(
            'input_text_color',
            [
                'label' => __('Text Color', 'blogzine'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .millers-search-input' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'input_background',
            [
                'label' => __('Background Color', 'blogzine'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .millers-search-input' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'input_placeholder_color',
            [
                'label' => __('Placeholder Color', 'blogzine'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .millers-search-input::placeholder' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'input_border',
                'label' => __('Border', 'blogzine'),
                'selector' => '{{WRAPPER}} .millers-search-input',
            ]
        );

        $this->add_control(
            'input_border_radius',
            [
                'label' => __('Border Radius', 'blogzine'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .millers-search-input' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'input_box_shadow',
                'label' => __('Box Shadow', 'blogzine'),
                'selector' => '{{WRAPPER}} .millers-search-input',
            ]
        );

        $this->add_responsive_control(
            'input_padding',
            [
                'label' => __('Padding', 'blogzine'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .millers-search-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $search_query = isset($_GET['s']) ? esc_attr($_GET['s']) : '';
        ?>
        <style>.millers-search-form {display: flex;align-items: center;position: relative;}.millers-search-input {width: 100%;padding: 10px 40px 10px 15px;font-size: 16px;border: 1px solid #ccc;border-radius: 5px;}.millers-search-input::placeholder {color: #999;}</style>
        <form method="get" action="<?php echo esc_url(home_url('/')); ?>" class="millers-search-form"><input type="search" class="millers-search-input" name="s" placeholder="Search..." value="<?php echo esc_attr($search_query); ?>"></form>
        <?php
    }
}
