<?php 
    // Content template for posts 
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(has_post_thumbnail() ? '' : 'no-thumb'); ?>>
    <?php 
        $p_title = get_the_title();
        if ( empty( trim( $p_title ) ) ) { $p_title = sprintf( esc_html__( 'Post from %s', 'blogzine' ), get_the_date() ); }
    ?>
    <?php if (is_archive() || is_home() || is_search()) : // archive ?>
        <!-- thumbnail -->
        <?php if (has_post_thumbnail()) : ?>
            <div class="post-thumbnail"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_post_thumbnail('medium', ['loading' => 'lazy']); ?></a></div>
        <?php endif; ?>
        <!-- title -->
        <div class="post-header"><h2 class="post-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo wp_kses_post( $p_title ); ?></a></h2></div>
        <!-- excerpt -->
        <div class="post-content"><?php the_excerpt(); ?></div>
        <!-- post meta -->
        <div class="list-post-meta">
            <div class="post-meta-left">
                <div class="author-avatar">
                    <?php echo get_avatar(get_the_author_meta('ID'), 50); ?>
                </div>
                <div class="left-meta-content">
                    <span class="post-author">
                        <?php _e('By', 'blogzine'); ?> 
                        <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                            <?php the_author(); ?>
                        </a>
                    </span> 
                    <div class="meta-box-date"><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php echo get_the_date('F j, Y'); ?></a></div>
                </div>
            </div>
            <div class="post-meta-right"><?php the_category(); ?></div>
        </div>
    <?php else : // single ?>
        <!-- title -->
        <h1 class="post-title"><?php echo wp_kses_post( $p_title ); ?></h1>
        <!-- post meta -->
        <div class="list-post-meta single-post">
            <div class="post-meta-left">
                <div class="author-avatar">
                    <?php echo get_avatar(get_the_author_meta('ID'), 50); ?>
                </div>
                <div class="left-meta-content">
                    <span class="post-author">
                        <?php _e('By', 'blogzine'); ?> 
                        <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                            <?php the_author(); ?>
                        </a>
                    </span> 
                    <div class="meta-box-date"><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>">Published <?php echo get_the_date('F j, Y'); ?></a></div>
                </div>
            </div>
            <div class="post-meta-right"><?php the_category(); ?></div>
        </div>
        <!-- thumbnail -->
        <?php if (has_post_thumbnail()) : ?>
            <div class="post-thumbnail view-full"><?php the_post_thumbnail('large', ['loading' => 'lazy']); ?></div>
        <?php endif; ?>
        <!-- content -->
        <div class="post-content"><?php the_content(); ?></div>
        <!-- after content sidebar -->
        <?php if (is_active_sidebar('post_after_content')) {dynamic_sidebar('post_after_content');} ?>
        <!-- tags -->
        <?php if (has_tag()) { ?><div class="post-tags">Tags: <?php the_tags('', ' ', ''); ?></div><?php } ?>
        <!-- navigation -->
        <div class="post-navigation">
            <div class="nav-previous">
                <?php 
                $prev_post = get_previous_post();
                if ($prev_post) :
                    $prev_thumb = get_the_post_thumbnail($prev_post->ID, 'thumbnail'); 
                ?>
                    <a href="<?php echo get_permalink($prev_post->ID); ?>">
                        <?php if ($prev_thumb) { ?><div class="nav-post-thumb"><?php echo wp_kses_post($prev_thumb); ?></div><?php } ?>
                        <div class="nav-post-content"><div class="nav-post-icon">←</div><div class="nav-post-title"><?php echo get_the_title($prev_post->ID); ?></div></div>
                    </a>
                <?php endif; ?>
            </div>
            <div class="nav-next">
                <?php 
                $next_post = get_next_post();
                if ($next_post) :
                    $next_thumb = get_the_post_thumbnail($next_post->ID, 'thumbnail'); 
                ?>
                    <a href="<?php echo get_permalink($next_post->ID); ?>">
                        <div class="nav-post-content"><div class="nav-post-icon">→</div><div class="nav-post-title"><?php echo get_the_title($next_post->ID); ?></div></div>
                        <?php if ($next_thumb) { ?><div class="nav-post-thumb"><?php echo wp_kses_post($next_thumb); ?></div><?php } ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <!-- post comments -->
        <?php if (comments_open() || get_comments_number()) : ?>
            <div class="comments-section"><?php comments_template(); ?></div>
        <?php endif; ?>
        <!-- related posts -->
        <?php
            $current_post_id = get_the_ID();
            $related_args = array(
                'category__in'   => wp_get_post_categories($current_post_id),
                'post__not_in'   => array($current_post_id),
                'posts_per_page' => 6,
                'orderby'        => 'rand'
            );
            $related_query = new WP_Query($related_args);
            if ($related_query->have_posts()) : ?>
                <h3>Related Posts</h3>
                <div class="post-grid related-posts">
                    <?php while ($related_query->have_posts()) : $related_query->the_post(); ?>
                        <article class="type-post <?php echo has_post_thumbnail() ? '' : 'no-thumb'; ?>">
                            <?php 
                                $p_inner_title = get_the_title();
                                if ( empty( trim( $p_inner_title ) ) ) { $p_inner_title = sprintf( esc_html__( 'Post from %s', 'blogzine' ), get_the_date() ); }
                            ?>
                            <!-- thumbnail -->
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="post-thumbnail"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_post_thumbnail('medium', ['loading' => 'lazy']); ?></a></div>
                            <?php endif; ?>
                            <!-- title -->
                            <div class="post-header"><h4 class="post-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo wp_kses_post( $p_inner_title ); ?></a></h4></div>
                            <!-- excerpt -->
                            <div class="post-content"><?php the_excerpt(); ?></div>
                            <!-- post meta -->
                            <div class="list-post-meta">
                                <div class="post-meta-left">
                                    <div class="author-avatar">
                                        <?php echo get_avatar(get_the_author_meta('ID'), 50); ?>
                                    </div>
                                    <div class="left-meta-content">
                                        <span class="post-author">
                                            <?php _e('By', 'blogzine'); ?> 
                                            <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                                                <?php the_author(); ?>
                                            </a>
                                        </span> 
                                        <div class="meta-box-date"><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php echo get_the_date('F j, Y'); ?></a></div>
                                    </div>
                                </div>
                                <div class="post-meta-right"><?php the_category(); ?></div>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>
        <?php endif; wp_reset_postdata(); ?>
        <!-- widgets sidebar -->
        <?php get_sidebar(); ?>
    <?php endif; ?>
</article>